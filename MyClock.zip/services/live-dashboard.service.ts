import { createClient } from "@/lib/supabase/server";

export interface LiveEmployee {
  id: string;
  full_name: string;
  avatar_url: string | null;
  working: boolean;
  lastPunch: string;
}

export async function getLiveEmployees(): Promise<LiveEmployee[]> {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("profiles")
    .select("*");

  console.log("LIVE EMPLOYEES:", data);

  if (error) throw error;

  return (data ?? []).map((employee: any) => ({
    id: employee.id,
    full_name: employee.full_name,
    avatar_url: employee.avatar_url,
    working: false,
    lastPunch: "",
  }));
}