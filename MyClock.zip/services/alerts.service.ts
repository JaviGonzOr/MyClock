import { createClient } from "@/lib/supabase/server";

export interface Alert {
  id: string;

  type:
    | "missing"
    | "late"
    | "working"
    | "vacation"
    | "overtime";

  employee: string;

  message: string;
}

export async function getAlerts(): Promise<Alert[]> {
  const supabase = await createClient();

  const alerts: Alert[] = [];

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const [employeesResult, punchesResult] =
    await Promise.all([
      supabase
        .from("profiles")
        .select("id,full_name"),

      supabase
        .from("punches")
        .select("*")
        .gte(
          "created_at",
          today.toISOString()
        ),
    ]);

  if (employeesResult.error) {
    throw employeesResult.error;
  }

  if (punchesResult.error) {
    throw punchesResult.error;
  }

  const employees =
    employeesResult.data ?? [];

  const punches =
    punchesResult.data ?? [];

  for (const employee of employees) {
    const employeePunches =
      punches.filter(
        (p) =>
          p.user_id === employee.id
      );

    if (
      employeePunches.length === 0
    ) {
      alerts.push({
        id: employee.id,
        type: "missing",
        employee:
          employee.full_name,
        message:
          "No ha fichado hoy",
      });
    }
  }

  return alerts;
}