import { createClient } from "@/lib/supabase/server";

export interface EmployeeStats {
  workedToday: string;
  workedMonth: string;
  punchesToday: number;
  lastPunch: string;
}

export async function getEmployeeStats(
  userId: string
): Promise<EmployeeStats> {
  const supabase = await createClient();

  const today = new Date();

  const start = new Date(today);
  start.setHours(0, 0, 0, 0);

  const month = new Date(
    today.getFullYear(),
    today.getMonth(),
    1
  );

  const { data, error } = await supabase
    .from("punches")
    .select("*")
    .eq("user_id", userId)
    .gte("created_at", month.toISOString())
    .order("created_at");

  if (error) {
    throw error;
  }

  const punches = data ?? [];

  const todayPunches = punches.filter(
    (p) => new Date(p.created_at) >= start
  );

  const lastPunch =
    punches.length > 0
      ? new Date(
          punches[punches.length - 1].created_at
        ).toLocaleString("es-ES")
      : "--";

  return {
    workedToday: "--:--",
    workedMonth: "--:--",
    punchesToday: todayPunches.length,
    lastPunch,
  };
}