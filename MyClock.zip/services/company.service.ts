import { companyRepository } from "@/repositories/company.repository";

export class CompanyService {
  load(id: string) {
    return companyRepository.find(id);
  }

  save(data: any) {
    return companyRepository.update(data);
  }
}

export const companyService =
  new CompanyService();