import { BaseRepository } from "./base.repository";
import { Company } from "@/types/company";

class CompanyRepository extends BaseRepository {
  async find(id: string): Promise<Company | null> {
    const { data, error } = await this.db
      .from("companies")
      .select("*")
      .eq("id", id)
      .maybeSingle();

    if (error) throw error;

    return data;
  }

  async update(company: Partial<Company> & { id: string }) {
    const { error } = await this.db
      .from("companies")
      .update(company)
      .eq("id", company.id);

    if (error) throw error;
  }
}

export const companyRepository =
  new CompanyRepository();