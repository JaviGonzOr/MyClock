import { NextResponse } from "next/server";

import { createClient } from "@supabase/supabase-js";

const admin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!,
);

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const {
      email,
      password,
      full_name,
      role = "employee",
      company_id = null,
    } = body;

    if (!email || !password || !full_name) {
      return NextResponse.json(
        {
          error: "Faltan datos obligatorios.",
        },
        {
          status: 400,
        },
      );
    }

    const { data: existing } = await admin
      .from("profiles")
      .select("id")
      .eq("email", email)
      .maybeSingle();

    if (existing) {
      return NextResponse.json(
        {
          error: "Ya existe un empleado con ese correo.",
        },
        {
          status: 400,
        },
      );
    }

    const { data, error } = await admin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
    });

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    const user = data.user;

    const { error: profileError } = await admin.from("profiles").insert({
      id: user.id,
      full_name,
      email,
      role,
      company_id,
      active: true,
    });

    if (profileError) {
      await admin.auth.admin.deleteUser(user.id);

      return NextResponse.json(
        {
          error: profileError.message,
        },
        { status: 400 },
      );
    }

    return NextResponse.json({
      success: true,
      user,
    });
  } catch {
    return NextResponse.json(
      {
        error: "Error interno",
      },
      {
        status: 500,
      },
    );
  }
}
