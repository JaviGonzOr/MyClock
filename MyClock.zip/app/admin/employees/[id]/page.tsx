import { notFound } from "next/navigation";
import { EmployeeHistory } from "@/components/admin/employee-history";
import { employeeService } from "@/services/employee.service";
import { EmployeeActions } from "@/components/admin/employee-actions";
import { AdminHeader } from "@/components/admin/admin-header";
import { EmployeeEditForm } from "@/components/admin/employee-edit-form";
import { getEmployeeStats } from "@/services/stats.service";
import { EmployeeStats } from "@/components/admin/employee-stats";

export default async function EmployeePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const employee = await employeeService.get(id);

  if (!employee) {
    notFound();
  }
  const stats = await getEmployeeStats(id);
  const punches = await employeeService.punches(id);

  return (
    <>
      <AdminHeader title={employee.full_name} subtitle={employee.email} />
      <EmployeeStats
        workedToday={stats.workedToday}
        workedMonth={stats.workedMonth}
        punchesToday={stats.punchesToday}
        lastPunch={stats.lastPunch}
      />
      <div className="px-8">
        <EmployeeActions id={employee.id} active={employee.active} />
      </div>

      <div className="p-8">
        <div className="mx-auto max-w-3xl">
          <EmployeeEditForm employee={employee} />
        </div>
      </div>
    </>
  );
  <div className="mx-auto mt-8 max-w-3xl">
    <EmployeeHistory punches={punches} />
  </div>;
}
