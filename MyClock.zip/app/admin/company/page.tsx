"use client";

import { AdminHeader } from "@/components/admin/admin-header";

export default function CompanyPage() {
  return (
    <>
      <AdminHeader
        title="Empresa"
        subtitle="Configuración general de la empresa"
      />

      <div className="p-8">

        <div className="mx-auto max-w-4xl rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">

          <h2 className="text-2xl font-bold text-slate-900">
            Información de la empresa
          </h2>

          <p className="mt-2 text-slate-500">
            Estos datos aparecerán en los informes y documentos.
          </p>

          <div className="mt-8 grid gap-6 md:grid-cols-2">

            <div>
              <label className="mb-2 block font-semibold text-slate-700">
                Nombre
              </label>

              <input
                className="w-full rounded-2xl border border-slate-300 p-3"
                placeholder="Mi Empresa SL"
              />
            </div>

            <div>
              <label className="mb-2 block font-semibold text-slate-700">
                Email
              </label>

              <input
                className="w-full rounded-2xl border border-slate-300 p-3"
                placeholder="info@empresa.com"
              />
            </div>

            <div>
              <label className="mb-2 block font-semibold text-slate-700">
                Teléfono
              </label>

              <input
                className="w-full rounded-2xl border border-slate-300 p-3"
                placeholder="+34..."
              />
            </div>

            <div>
              <label className="mb-2 block font-semibold text-slate-700">
                Dirección
              </label>

              <input
                className="w-full rounded-2xl border border-slate-300 p-3"
                placeholder="Calle..."
              />
            </div>

          </div>

          <button className="mt-8 rounded-2xl bg-violet-600 px-6 py-3 font-semibold text-white hover:bg-violet-700">
            Guardar cambios
          </button>

        </div>

      </div>
    </>
  );
}