import Link from "next/link";

export function QuickActions() {
  return (
    <div className="grid gap-4 md:grid-cols-4">

      <Link
        href="/admin/employees/new"
        className="rounded-2xl bg-violet-600 p-6 text-center font-bold text-white"
      >
        Nuevo empleado
      </Link>

      <Link
        href="/admin/schedules/new"
        className="rounded-2xl bg-indigo-600 p-6 text-center font-bold text-white"
      >
        Nuevo horario
      </Link>

      <Link
        href="/admin/reports"
        className="rounded-2xl bg-emerald-600 p-6 text-center font-bold text-white"
      >
        Informes
      </Link>

      <Link
        href="/admin/company"
        className="rounded-2xl bg-orange-600 p-6 text-center font-bold text-white"
      >
        Empresa
      </Link>

    </div>
  );
}