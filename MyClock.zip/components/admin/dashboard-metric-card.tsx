import { ReactNode } from "react";

type Props = {
  title: string;
  value: string | number;
  icon: ReactNode;
};

export function DashboardMetricCard({
  title,
  value,
  icon,
}: Props) {
  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">

      <div className="flex justify-between">

        <div>

          <p className="text-slate-500">
            {title}
          </p>

          <h2 className="mt-2 text-4xl font-black text-slate-900">
            {value}
          </h2>

        </div>

        <div className="rounded-2xl bg-violet-100 p-4 text-violet-700">

          {icon}

        </div>

      </div>

    </div>
  );
}