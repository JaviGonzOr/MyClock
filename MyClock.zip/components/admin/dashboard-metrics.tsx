import {
  Users,
  Clock3,
  Calendar,
  Fingerprint,
} from "lucide-react";

import { DashboardMetricCard } from "./dashboard-metric-card";
import { getDashboardMetrics } from "@/services/admin.service";

export async function DashboardMetrics() {
  const metrics =
    await getDashboardMetrics();

  return (
    <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">

      <DashboardMetricCard
        title="Empleados"
        value={metrics.employees}
        icon={<Users size={28} />}
      />

      <DashboardMetricCard
        title="Trabajando"
        value={metrics.working}
        icon={<Clock3 size={28} />}
      />

      <DashboardMetricCard
        title="Horarios"
        value={metrics.schedules}
        icon={<Calendar size={28} />}
      />

      <DashboardMetricCard
        title="Fichajes hoy"
        value={metrics.punchesToday}
        icon={<Fingerprint size={28} />}
      />

    </div>
  );
}